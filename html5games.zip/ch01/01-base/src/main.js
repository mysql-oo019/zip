const gameType = "awesome";
alert(`Let's make ${gameType} games!`);
