$(document).ready(function(){
	$("h1").after("<p>I've just inserted a paragraph</p>");	
});